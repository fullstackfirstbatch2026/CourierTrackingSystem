
COURIERFLOW UI UPGRADE
======================

These files are an ADD-ON to the existing CourierFlow project.

Files:
1. courierflow-ui-upgrade.css
2. courierflow-ui-upgrade.js

INSTALL
-------
1. Copy courierflow-ui-upgrade.css into:
   src/main/resources/static/

2. Copy courierflow-ui-upgrade.js into:
   src/main/resources/static/

3. Open index.html and add these lines BEFORE </body>:

   <link rel="stylesheet" href="courierflow-ui-upgrade.css">
   <script src="courierflow-ui-upgrade.js"></script>

IMPORTANT:
The upgrade script uses your existing REST API:
   GET    /api/shipments
   GET    /api/tracking/{trackingNumber}
   PUT    /api/shipments/{id}
   DELETE /api/shipments/{id}

It does NOT require a database migration.

WHAT IT ADDS
------------
- Shipment status filters
- Global shipment search
- ETA display (presentation-only)
- Shipment action menu
- View shipment modal
- Edit shipment modal using PUT
- Delete confirmation modal
- Track shipment shortcut
- CSV export
- Toast notifications
- Help modal
- Keyboard shortcuts
- Page-entry animations
- Hover/lift animations
- Loading-friendly UI primitives
- Sidebar collapse persistence
- Better status badges

IMPORTANT ETA NOTE
------------------
Your current Shipment entity does not contain an ETA/expectedDeliveryDate field.
Therefore the displayed ETA is calculated in the browser.

If you want ETA to be REAL and saved in MySQL, the next backend phase should add:
   expectedDeliveryDate
and optionally:
   courier
   lastUpdated
   currentLocation

Do not send those fields to the current backend until the Java entity,
repository/service/controller and MySQL schema are updated.

SAFE WORKFLOW
-------------
First run the app directly from IntelliJ and test the UI.
Only after everything works:

   .\mvnw.cmd clean package "-Dmaven.test.skip=true"
   docker build -t couriertracking .

Then recreate the Docker container.

DO NOT replace your current style.css or script.js blindly.
These are additive upgrade files designed to sit on top of them.
